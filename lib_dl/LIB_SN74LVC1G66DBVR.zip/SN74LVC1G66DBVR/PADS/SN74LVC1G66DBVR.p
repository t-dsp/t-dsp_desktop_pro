*PADS-LIBRARY-PART-TYPES-V9*

SN74LVC1G66DBVR SOT95P280X145-5N I ANA 7 1 0 0 0
TIMESTAMP 2025.08.25.11.07.13
"Mouser Part Number" 595-SN74LVC1G66DBVR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74LVC1G66DBVR?qs=pt%2FIv5r0EPcNpRLTEQzKFQ%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74LVC1G66DBVR
"Description" SINGLE BILATERAL ANALOG SWITCH
"Datasheet Link" http://www.ti.com/lit/gpn/sn74lvc1g66
"Geometry.Height" 1.45mm
GATE 1 5 0
SN74LVC1G66DBVR
1 0 U A
2 0 U B
3 0 U GND
4 0 U C
5 0 U VCC

*END*
*REMARK* SamacSys ECAD Model
373347/257563/2.50/5/3/Integrated Circuit
