*PADS-LIBRARY-PART-TYPES-V9*

EC11E15204A3 EC11E15204A3 I ANA 7 1 0 0 0
TIMESTAMP 2025.03.25.22.26.36
"Mouser Part Number" 688-EC11E15204A3
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Alps-Alpine/EC11E15204A3?qs=PoKhxlfUXjIkxNd9QfxiYw%3D%3D
"Manufacturer_Name" ALPS Electric
"Manufacturer_Part_Number" EC11E15204A3
"Description" Alps Electric 15 Pulse Incremental Mechanical Rotary Encoder with a 6 mm Flat Shaft, Through Hole
"Datasheet Link" https://www.alps.com/prod/info/E/HTML/Encoder/Incremental/EC11/EC11E15204A3.html
"Geometry.Height" 24.5mm
GATE 1 7 0
EC11E15204A3
A1 0 U A1
B1 0 U B1
C1 0 U C1
D1 0 U DUMMY1
D2 0 U DUMMY2
MH1 0 U MH1
MH2 0 U MH2

*END*
*REMARK* SamacSys ECAD Model
242172/257563/2.50/7/4/Integrated Circuit
