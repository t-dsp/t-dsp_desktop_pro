*PADS-LIBRARY-PART-TYPES-V9*

TPS259531DSGT SON50P200X200X80-9N I ANA 7 1 0 0 0
TIMESTAMP 2025.08.26.11.47.04
"Mouser Part Number" 595-TPS259531DSGT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPS259531DSGT?qs=W0yvOO0ixfHjdZF3aZpCfQ%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS259531DSGT
"Description" 2.7V to 18V, 4A, 34m eFuse with fast overvoltage protection
"Datasheet Link" http://www.ti.com/lit/gpn/TPS2595
"Geometry.Height" 0.8mm
GATE 1 9 0
TPS259531DSGT
1 0 U DVDT
2 0 U EN/UVLO
3 0 U IN_1
4 0 U IN_2
9 0 U GND_2
8 0 U GND_1
7 0 U ILM
6 0 U \FLT
5 0 U OUT

*END*
*REMARK* SamacSys ECAD Model
1435230/257563/2.50/9/3/Integrated Circuit
