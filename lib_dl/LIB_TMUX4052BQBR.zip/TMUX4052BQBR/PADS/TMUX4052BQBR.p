*PADS-LIBRARY-PART-TYPES-V9*

TMUX4052BQBR TMUX4052BQBR I ANA 9 1 0 0 0
TIMESTAMP 2025.04.13.11.33.03
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TMUX4052BQBR
"Mouser Part Number" 595-TMUX4052BQBR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TMUX4052BQBR?qs=1Kr7Jg1SGW8hnMZDRGjgXw%3D%3D
"Arrow Part Number" TMUX4052BQBR
"Arrow Price/Stock" https://www.arrow.com/en/products/tmux4052bqbr/texas-instruments?region=nac
"Description" Multiplexer Switch ICs +/-12-V, 4:1, 2-channel multiplexer with 1.8-V logic compatible logic 16-WQFN -55 to 125
"Datasheet Link" https://www.ti.com/lit/ds/symlink/tmux4052.pdf?ts=1730367531408&ref_url=https%253A%252F%252Fwww.ti.com%252Fproduct%252FTMUX4052%252Fpart-details%252FTMUX4052BQBR
"Geometry.Height" 0.8mm
GATE 1 17 0
TMUX4052BQBR
1 0 U S0B
2 0 U S2B
3 0 U DB
4 0 U S3B
5 0 U S1B
6 0 U \EN
7 0 U VSS
8 0 U GND_1
9 0 U A1
10 0 U A0
11 0 U S3A
12 0 U S0A
13 0 U DA
14 0 U S1A
15 0 U S2A
16 0 U VDD
17 0 U GND_2

*END*
*REMARK* SamacSys ECAD Model
19096883/257563/2.50/17/3/Integrated Circuit
